<!DOCTYPE html>
<html lang="en">
<head>
	<?php echo $__env->make('website.includes.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Fixing Internet Explorer-->
    <!--[if lt IE 9]>
        <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
        <script src="js/html5shiv.js"></script>
    <![endif]-->
    
</head>
<body>
<div class="boxed_wrapper">
<!--Start Preloader -->

<!--End Preloader -->  

<!--Start Top bar area -->  
<section class="top-bar-area">
    <div class="container">
        <div class="clearfix">
            <div class="pull-left"><p>Welcome to Advanced System Integration Solutions</p></div>
            <div class="pull-right">
                <p><i class="fa fa-clock-o"></i>Sunday - Thursday : 8:00 AM to 7:00 Pm</p>
            </div>
        </div>

    </div>
</section>
<!--End Top bar area --> 
 
<?php echo $__env->make('website.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      
<?php echo $__env->yieldContent('content'); ?>


<?php echo $__env->make('website.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('website.includes.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</div>
</body>
</html><?php /**PATH H:\assis\example-app\resources\views/website/layouts/app.blade.php ENDPATH**/ ?>