


<?php $__env->startSection('styles'); ?>

<!-- INTERNAl Summernote css -->
<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/summernote/summernote.css')); ?>?v=<?php echo time(); ?>">

<!-- INTERNAl Dropzone css -->
<link href="<?php echo e(asset('assets/plugins/dropzone/dropzone.css')); ?>?v=<?php echo time(); ?>" rel="stylesheet" />
<!--  BEGIN CUSTOM STYLE FILE  -->
    <link href="<?php echo e(asset('assets')); ?>/plugins/loaders/custom-loader.css" rel="stylesheet" type="text/css" />
    <!--  END CUSTOM STYLE FILE  --> 
<?php $__env->stopSection(); ?>

					<?php $__env->startSection('content'); ?>

					<!--Page header-->
					<div class="page-header d-xl-flex d-block">
						<div class="page-leftheader">
							<h4 class="page-title"><span class="font-weight-normal text-muted ms-2">Edit Product</span></h4>
						</div>
					</div>
					<!--End Page header-->

					<!-- Create Ticket List-->
					<div class="col-xl-12 col-lg-12 col-md-12">
						<div class="card ">
							<div class="card-header border-0">
								<h4 class="card-title">Edit Product</h4>
							</div>
							<!-- //id="admin_form" -->
							<form method="post" id="admin_form" enctype="multipart/form-data" >
								<?php echo csrf_field(); ?>
								<input type="hidden" name="id" value="<?php echo e($product->id); ?>">
								<div class="card-body">
									<div class="form-group ">
										<div class="row">
											<div class="col-md-3">
												<label class="form-label mb-0 mt-2">Product Title  <span class="text-red">*</span></label>
											</div>
											<div class="col-md-9">
												<input type="text" id="title" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Title" name="title" value="<?php echo e($product->title); ?>">
												<span id="TitleError" class="text-danger alert-message"></span>
												<?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
												
													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

											</div>
										</div>
									</div>
									
									<div class="form-group">
										<div class="row">
											<div class="col-md-3">
												<label class="form-label mb-0 mt-2">Product Category<span class="text-red">*</span></label>
											</div>
											<div class="col-md-9">
												<select  class="form-control select2-show-search  select2 <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  data-placeholder="Select Category" name="category" id="category">
													<option label="Select Category"></option>
													<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

														<option value="<?php echo e($category->id); ?>" <?php if($category->id == $product->category_id): ?> selected <?php endif; ?>><?php echo e($category->name); ?></option>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

												</select>
												<span id="CategoryError" class="text-danger alert-message"></span>
												<?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

											</div>
										</div>
									</div>
									<div class="form-group ticket-summernote ">
										<div class="row">
											<div class="col-md-3">
												<label class="form-label mb-0 mt-2">Product Sort Description<span class="text-red">*</span></label>
											</div>
											<div class="col-md-9">
												<textarea class=" form-control <?php $__errorArgs = ['sort_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="7" name="sort_description" ><?php echo e($product->sort_description); ?></textarea>
												<span id="SortDescriptionError" class="text-danger alert-message"></span>
												<?php $__errorArgs = ['sort_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

											</div>
										</div>
									</div>
									<div class="form-group ticket-summernote ">
										<div class="row">
											<div class="col-md-3">
												<label class="form-label mb-0 mt-2">Product Description<span class="text-red">*</span></label>
											</div>
											<div class="col-md-9">
												<textarea class="summernote form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="7" name="description" id="me"><?php echo e($product->description); ?></textarea>
												<span id="DescriptionError" class="text-danger alert-message"></span>
												<?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

											</div>
										</div>
									</div>
									
									<div class="form-group">
										<div class="row">
											<div class="col-md-3">
												<label class="form-label mb-0 mt-2">Main Thumbnail</label>
											</div>
											<div class="col-md-9">
												<input type="file" accept="image/*" name="main_image">
												<p>W:765 H:507</p>
												<span id="MainImageError" class="text-danger alert-message"></span>
												<?php $__errorArgs = ['main_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
											</div>

										</div>
									</div>
									<div class="form-group">
										<div class="row">
											<div class="col-md-3">
												<label class="form-label mb-0 mt-2">Banner</label>
											</div>
											<div class="col-md-9">
												<input type="file" accept="image/*" name="banner">
												<p>W:1920 H:400</p>
												<span id="BannerError" class="text-danger alert-message"></span>
												<?php $__errorArgs = ['banner'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
											</div>

										</div>
									</div>
									<div class="form-group">
										<div class="row">
											<div class="col-md-3">
												<label class="form-label mb-0 mt-2">Image one</label>
											</div>
											<div class="col-md-9">
												<input type="file" accept="image/*" name="image_one">
												<p>W:375 H:238</p>
												<span id="ImageOneError" class="text-danger alert-message"></span>
												<?php $__errorArgs = ['image_one'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
											</div>

										</div>
									</div>
									
									<div class="form-group">
										<div class="row">
											<div class="col-md-3">
												<label class="form-label mb-0 mt-2">Image two</label>
											</div>
											<div class="col-md-9">
												<input type="file" accept="image/*" name="image_two">
												<p>W:375 H:238</p>
												<span id="ImageTwoError" class="text-danger alert-message"></span>
												<?php $__errorArgs = ['image_two'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="invalid-feedback" role="alert">
														<strong><?php echo e($message); ?></strong>
													</span>
												<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
											</div>

										</div>
									</div>
									<div class="form-group">
										<div class="row">
											<div class="col-md-3">
												<label class="form-label mb-0 mt-2">Upload File</label>
											</div>
											<div class="col-md-9">
												<input type="file" name="file">
											</div>
										</div>
									</div>
								</div>
								<div class="card-footer">
									<div class="form-group float-end">
										<input type="submit"  class="btn btn-secondary btn-lg purchasecode" id="createticketbtnstr" value="Create ticket" >
										<button type="submit" id="createticketbtn" class="btn btn-secondary btn-lg purchasecode" disabled="">Loading.. <i class="fa fa-spinner fa-spin"></i></button>
                                    
                                    
									</div>
								</div>
							</form>
						</div>
					</div>
					<!--End Create Ticket List-->
										<?php $__env->stopSection(); ?>

		<?php $__env->startSection('scripts'); ?>
		

		<!-- INTERNAL Vertical-scroll js-->
		<script src="<?php echo e(asset('assets/plugins/vertical-scroll/jquery.bootstrap.newsbox.js')); ?>?v=<?php echo time(); ?>"></script>
		<script type="text/javascript">
						$("#createticketbtn").hide();
				        $("#createticketbtnstr").click(function(){
					    	$("#createticketbtnstr").hide();
						    $("#createticketbtn").show();
						 });

					</script>

		<!-- INTERNAL Summernote js  -->
		<script src="<?php echo e(asset('assets/plugins/summernote/summernote.js')); ?>?v=<?php echo time(); ?>"></script>

		<!-- INTERNAL Index js-->
		<script src="<?php echo e(asset('assets/js/support/support-sidemenu.js')); ?>?v=<?php echo time(); ?>"></script>
		<script src="<?php echo e(asset('assets/js/support/support-createticket.js')); ?>?v=<?php echo time(); ?>"></script>
		<script src="<?php echo e(asset('assets/js/select2.js')); ?>?v=<?php echo time(); ?>"></script>

		<!-- INTERNAL Dropzone js-->
		<script src="<?php echo e(asset('assets/plugins/dropzone/dropzone.js')); ?>?v=<?php echo time(); ?>"></script>

		<script type="text/javascript">

			
				
			// Csrf field
			$.ajaxSetup({
				headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
				}
			});
			


			// summernote 
			$('.note-editable').on('keyup', function(e){
				localStorage.setItem('adminmessage', e.target.innerHTML)
			})

			// store subject to local
			$('#subject').on('keyup', function(e){
				localStorage.setItem('adminsubject', e.target.value)
			})
			

			// onload get the data from local
			$(window).on('load', function(){
				if(localStorage.getItem('adminsubject') || localStorage.getItem('adminmessage') || localStorage.getItem('adminemail')){

					document.querySelector('#subject').value = localStorage.getItem('adminsubject');
					document.querySelector('#email').value = localStorage.getItem('adminemail');
					document.querySelector('.summernote').innerHTML = localStorage.getItem('adminmessage');
					document.querySelector('.note-editable').innerHTML = localStorage.getItem('adminmessage');
				}
			})

			// Create Ticket 
			$('body').on('submit', '#admin_form', function (e) {
				e.preventDefault();
				$('#TitleError').html('');
				$('#SortDescriptionError').html('');
				$('#DescriptionError').html('');
				$('#CategoryError').html('');
				$('#MainImageError').html('');
				$('#ImageOneError').html('');
				$('#ImageTwoError').html('');
				$('#BannerError').html('');
				var actionType = $('#btnsave').val();
				var fewSeconds = 2;
				$('#btnsave').html('Sending..');
				$('#btnsave').prop('disabled', true);
					setTimeout(function(){
						$('#btnsave').prop('disabled', false);
					}, fewSeconds*1000);

					$("#createticketbtnstr").hide();
						$("#createticketbtn").show();
				var formData = new FormData(this);

				$.ajax({
					type:'post',
					url: '<?php echo e(url('/admin/update-prodcuct')); ?>',
					data: formData,
					cache:false,
					contentType: false,
					processData: false,
	
					success: (data) => {
						

						$('#TitleError').html('');
						$('#SortDescriptionError').html('');
						$('#DescriptionError').html('');
						$('#CategoryError').html('');
						$('#MainImageError').html('');
						$('#ImageOneError').html('');
						$('#ImageTwoError').html('');
						$('#BannerError').html('');
						toastr.success(data.success);
						if(localStorage.getItem('adminsubject') || localStorage.getItem('adminmessage') || localStorage.getItem('adminemail')){
							localStorage.removeItem("adminsubject");
							localStorage.removeItem("adminmessage");
							localStorage.removeItem("adminemail");
						}
						window.location.replace('<?php echo e(url('admin/allprodcucts')); ?>');
						
						
						
						
					},
					error: function(data){

						$('#TitleError').html(data.responseJSON.errors.title);
						$('#SortDescriptionError').html(data.responseJSON.errors.sort_description);
						$('#DescriptionError').html(data.responseJSON.errors.description);
						$('#CategoryError').html(data.responseJSON.errors.category);
						$('#MainImageError').html(data.responseJSON.errors.main_image);
						$('#ImageOneError').html(data.responseJSON.errors.image_one);
						$('#ImageTwoError').html(data.responseJSON.errors.image_two);
						$('#BannerError').html(data.responseJSON.errors.banner);
						$("#createticketbtnstr").show();
						$("#createticketbtn").hide();
						
					}
				});
				
			});

			
		</script>

		<!-- <script>
			

	        $(".note-codable").on('keyup', function() {
		    	$("#createticketbtnstr").show();
				$("#createticketbtn").hide();
			});

	        $('#subject').on('keyup', function() {
		    	$("#createticketbtnstr").show();
				$("#createticketbtn").hide();
			});

			$('#email').on('keyup', function() {
		    	$("#createticketbtnstr").show();
				$("#createticketbtn").hide();
			});
			$('#category').on('change', function() {
		    	$("#createticketbtnstr").show();
				$("#createticketbtn").hide();
			});
    </script> -->

		<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\assis\example-app\resources\views/admin/viewproduct/editproduct.blade.php ENDPATH**/ ?>