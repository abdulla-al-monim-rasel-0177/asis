



<?php $__env->startSection('styles'); ?>

        <!-- INTERNAL owl-carousel css-->
        <link href="<?php echo e(asset('assets/plugins/owl-carousel/owl-carousel.css')); ?>?v=<?php echo time(); ?>" rel="stylesheet" />


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.adminmaster", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\assis\example-app\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>