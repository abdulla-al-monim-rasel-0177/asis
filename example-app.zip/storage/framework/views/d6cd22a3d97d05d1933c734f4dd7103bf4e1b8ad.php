

<?php $__env->startSection('content'); ?>
<!--Start breadcrumb area-->     
<section class="breadcrumb-area" style="background-image: url(<?php echo e(asset('fontend')); ?>/images/background/3.jpg);">
	<div class="container text-center">
		<h1>Products</h1>
	</div>
</section>
<!--End breadcrumb area-->




<section class="project-content sec-padd">
    <div class="container">
        <ul class="gallery-filter post-filter">
            <li class="filter active" data-filter=".filter-item"><span>All</span></li>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="filter" data-filter=".<?php echo e($category->name); ?>"><span><?php echo e($category->name); ?></span></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- <li class="filter" data-filter=".agricultural"><span>Agricultural</span></li>
            <li class="filter" data-filter=".chemical"><span>Chemical</span></li>
            <li class="filter" data-filter=".mechanical"><span>Mechanical</span></li>
            <li class="filter" data-filter=".power-energy"><span>Power Energy</span></li> -->
        </ul>

        <div class="row masonary-layout filter-layout">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mix col-sm-6 <?php echo e($product->category->name); ?> filter-item">
                <div class="single-project-item">
                    <div class="img-box">
                        <img src="<?php echo e(asset($product->main_image)); ?>" alt="Awesome Image"/>
                        <div class="overlay">
                            <div class="box">
                                <div class="top-box">
                                    <div class="title">
                                        <a href="<?php echo e(route('website.product',[$product->id,$product->slug])); ?>"><h3><?php echo e($product->title); ?></h3></a>
                                    </div>
                                </div>
                                <div class="bottom-box">
                                    <ul>
                                        <li><a data-group="1" href="<?php echo e(asset($product->main_image)); ?>" class="img-popup"><i class="fa fa-search-plus"></i></a></li>
                                        <li><a href="<?php echo e(route('website.product',[$product->id,$product->slug])); ?>"><i class="fa fa-link"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
    </div>
</section>

<div class="call-out2">
    <div class="container">
        <div class="clearfix">
            <div class="float_left">
                <h4>Have any question or need any business consultation?</h4>
            </div>
            <div class="float_right">
                <a href="contact.html" class="thm-btn bg-clr2">Request Quote</a>
            </div>
        </div>
                
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("website.layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\assis\example-app\resources\views/website/products.blade.php ENDPATH**/ ?>