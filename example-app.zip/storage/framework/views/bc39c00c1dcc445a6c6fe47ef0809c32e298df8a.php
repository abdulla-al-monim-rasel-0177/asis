

<?php $__env->startSection('content'); ?>
<!--Start breadcrumb area-->     
<section class="breadcrumb-area" style="background-image: url(<?php echo e(asset('fontend')); ?>/images/background/3.jpg);">
	<div class="container text-center">
		<h1>Our Solution</h1>
	</div>
</section>
<!--End breadcrumb area-->


<section class="our-services">
    <div class="container">    
        <div class="row">
            <?php $__currentLoopData = $solutions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solution): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 col-sm-6">
                <div class="single-our-service">
                    <figure class="img-box">
                        <a href="<?php echo e(route('website.solution',[$solution->id,$solution->slug])); ?>"><img src="<?php echo e(asset($solution->image_one)); ?>"
                                alt="Awesome Image"></a>
                    </figure>
                    <a href="<?php echo e(route('website.solution',[$solution->id,$solution->slug])); ?>">
                        <h4 class="line-1-truncate"><?php echo e($solution->title); ?></h4>
                    </a>
                    <p class="line-2-truncate"><?php echo e($solution->sort_description); ?></p>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("website.layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\assis\example-app\resources\views/website/solutions.blade.php ENDPATH**/ ?>