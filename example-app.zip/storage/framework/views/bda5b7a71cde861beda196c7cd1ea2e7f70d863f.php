<meta charset="UTF-8"> <title>Asis</title> <!-- responsive meta --> <meta name="viewport" content="width=device-width,
	initial-scale=1"> <!-- For IE -->
<meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- master stylesheet --> <link rel="stylesheet"
	href="<?php echo e(asset('fontend')); ?>/css/style.css">
<!-- Responsive stylesheet -->
	<link rel="stylesheet" href="<?php echo e(asset('fontend')); ?>/css/responsive.css">
	<!-- <link rel="stylesheet" href="<?php echo e(asset('public')); ?>/css/app.css"> -->
    <!-- Favicon -->
<link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('fontend')); ?>/images/favicon/apple-touch-icon.png"> <link
	rel="icon" type="image/png" href="<?php echo e(asset('fontend')); ?>/images/favicon/favicon-32x32.png" sizes="32x32"> <link
	rel="icon" type="image/png" href="<?php echo e(asset('fontend')); ?>/images/favicon/favicon-16x16.png" sizes="16x16"><?php /**PATH H:\assis\example-app\resources\views/website/includes/styles.blade.php ENDPATH**/ ?>