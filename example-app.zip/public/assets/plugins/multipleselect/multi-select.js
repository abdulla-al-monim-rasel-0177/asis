(function($) {
	"use strict";
	//filter-multiple
	$('.filter-multi').multipleSelect({
		filter: true,
		placeholder: 'Choose'
	})


})(jQuery);