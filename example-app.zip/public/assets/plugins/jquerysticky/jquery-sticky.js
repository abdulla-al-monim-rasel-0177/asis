$(document).ready(function() {
    $.jquerySticky("#scroll-stickybar",{offset: {top: 110}});
});