<section class="why-chooseus sec-padd2">
    <div class="container">

        <div class="section-title center">
            <h2>why choose Us</h2>
        </div>
        
        <div class="row">
        

            <div class="item col-lg-4 col-md-6 col-sm-12 col-xs-12">
                <!--inner-box-->
                <div class="inner-box wow fadeIn animated animated" data-wow-delay="0ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: fadeIn;">
   
                    <!--icon-box-->
                    <div class="icon_box">
                        <span class="flaticon-people-1"></span>
                    </div>
                    
                    <h4>EXPERIENCED</h4>
                    <div class="text"><p>Doin' it our way. Nothin's gonna turn us back now. Straight ahead and on the track now. </p></div>
                </div>
            </div>      
            <div class="item col-lg-4 col-md-6 col-sm-12 col-xs-12">
                <!--inner-box-->
                <div class="inner-box wow fadeIn animated animated" data-wow-delay="0ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: fadeIn;">
   
                    <!--icon-box-->
                    <div class="icon_box">
                        <span class="flaticon-sun"></span>
                    </div>
                    
                    <h4>PROFESSIONAL SERVICE</h4>
                    <div class="text"><p>Doin' it our way. Nothin's gonna turn us back now. Straight ahead and on the track now.</p></div>
                </div>
            </div>      
            <div class="item col-lg-4 col-md-6 col-sm-12 col-xs-12">
                <!--inner-box-->
                <div class="inner-box wow fadeIn animated animated" data-wow-delay="0ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: fadeIn;">
   
                    <!--icon-box-->
                    <div class="icon_box">
                        <span class="flaticon-people-2"></span>
                    </div>
                    
                    <h4>PUBLIC PROJECTS</h4>
                    <div class="text"><p>Doin' it our way. Nothin's gonna turn us back now. Straight ahead and on the track now.</p></div>
                </div>
            </div>      
            <div class="item col-lg-4 col-md-6 col-sm-12 col-xs-12">
                <!--inner-box-->
                <div class="inner-box wow fadeIn animated animated" data-wow-delay="0ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: fadeIn;">
   
                    <!--icon-box-->
                    <div class="icon_box">
                        <span class="flaticon-factory"></span>
                    </div>
                    
                    <h4>SUPERIOR QUALITY</h4>
                    <div class="text"><p>Doin' it our way. Nothin's gonna turn us back now. Straight ahead and on the track now. </p></div>
                </div>
            </div>      
            <div class="item col-lg-4 col-md-6 col-sm-12 col-xs-12">
                <!--inner-box-->
                <div class="inner-box wow fadeIn animated animated" data-wow-delay="0ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: fadeIn;">
   
                    <!--icon-box-->
                    <div class="icon_box">
                        <span class="flaticon-arrows"></span>
                    </div>
                    
                    <h4>COMPETITIVE PRICE</h4>
                    <div class="text"><p>Doin' it our way. Nothin's gonna turn us back now. Straight ahead and on the track now. </p></div>
                </div>
            </div>      
            <div class="item col-lg-4 col-md-6 col-sm-12 col-xs-12">
                <!--inner-box-->
                <div class="inner-box wow fadeIn animated animated" data-wow-delay="0ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: fadeIn;">
   
                    <!--icon-box-->
                    <div class="icon_box">
                        <span class="flaticon-technology-1"></span>
                    </div>
                    
                    <h4>TIME DELIVERY</h4>
                    <div class="text"><p>Doin' it our way. Nothin's gonna turn us back now. Straight ahead and on the track now. </p></div>
                </div>
            </div>      
            
        </div>
    </div>
</section>

<section class="testimonial padd3">
    <div class="container">
        <div class="section-title center">
            <h2>Client Feedback</h2>
        </div>
        <div class="testimonial-carousel">
            <div class="testimonial-item">
                <div class="content">
                    <span class="fa fa-quote-left"></span>
                    <p>Lorem ipsum dolor sit amet ment tionim sea. Ei explicari evertitur uptatum vi core zupitor inciderint reforin alienum</p>

                    <ul class="rating">
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                    </ul>
                </div>
                <div class="author">
                    <ul class="list-inline">
                        <li>
                            <img src="{{asset('fontend')}}/images/team/1.png" alt="">
                        </li>
                        <li>
                            <h5>Allen Duckeat</h5>
                            <p>Newyork</p>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="testimonial-item">
                <div class="content">
                    <span class="fa fa-quote-left"></span>
                    <p>Lorem ipsum dolor sit amet ment tionim sea. Ei explicari evertitur uptatum vi core zupitor inciderint reforin alienum</p>

                    <ul class="rating">
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                    </ul>
                </div>
                <div class="author">
                    <ul class="list-inline">
                        <li>
                            <img src="{{asset('fontend')}}/images/team/2.png" alt="">
                        </li>
                        <li>
                            <h5>mack raider</h5>
                            <p>California</p>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="testimonial-item">
                <div class="content">
                    <span class="fa fa-quote-left"></span>
                    <p>Lorem ipsum dolor sit amet ment tionim sea. Ei explicari evertitur uptatum vi core zupitor inciderint reforin alienum</p>

                    <ul class="rating">
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                        <li class="fa fa-star"></li>
                    </ul>
                </div>
                <div class="author">
                    <ul class="list-inline">
                        <li>
                            <img src="{{asset('fontend')}}/images/team/3.png" alt="">
                        </li>
                        <li>
                            <h5>Don Flethcer</h5>
                            <p>Los Angeles</p>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>