<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-angle-up"></span></div>
<div class="prealoader"></div>
<!-- main jQuery -->
<script src="{{asset('fontend')}}/js/jquery.js"></script>
<!-- bootstrap -->
<script src="{{asset('fontend')}}/js/bootstrap.min.js"></script>
<!-- bx slider -->
<script src="{{asset('fontend')}}/js/jquery.bxslider.min.js"></script>
<!-- count to -->
<script src="{{asset('fontend')}}/js/jquery.countTo.js"></script>
<!-- owl carousel -->
<script src="{{asset('fontend')}}/js/owl.carousel.min.js"></script>
<!-- validate -->
<script src="{{asset('fontend')}}/js/validation.js"></script>
<!-- mixit up -->
<script src="{{asset('fontend')}}/js/jquery.mixitup.min.js"></script>
<!-- easing -->
<script src="{{asset('fontend')}}/js/jquery.easing.min.js"></script>
<!-- gmap helper -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAHzPSV2jshbjI8fqnC_C4L08ffnj5EN3A"></script>
<!--gmap script-->
<script src="{{asset('fontend')}}/js/gmaps.js"></script>
<script src="{{asset('fontend')}}/js/map-helper.js"></script>
<!-- fancy box -->
<script src="{{asset('fontend')}}/js/jquery.fancybox.pack.js"></script>
<script src="{{asset('fontend')}}/js/jquery.appear.js"></script>
<!-- isotope script-->
<script src="{{asset('fontend')}}/js/isotope.js"></script>
<script src="{{asset('fontend')}}/js/jquery.prettyPhoto.js"></script> 
<script src="{{asset('fontend')}}/js/jquery.bootstrap-touchspin.js"></script>

<!-- jQuery ui js -->
<script src="{{asset('fontend')}}/js/jquery-ui.js"></script>
<script src="{{asset('fontend')}}/js/SmoothScroll.js"></script>
<script src="{{asset('fontend')}}/js/validation.js"></script>
<script src="{{asset('fontend')}}/js/wow.min.js"></script>



    <!-- revolution slider js -->
    <script src="{{asset('fontend')}}/js/jquery.themepunch.tools.min.js"></script>
    <script src="{{asset('fontend')}}/js/jquery.themepunch.revolution.min.js"></script>
    <script src="{{asset('fontend')}}/js/revolution.extension.actions.min.js"></script>
    <script src="{{asset('fontend')}}/js/revolution.extension.carousel.min.js"></script>
    <script src="{{asset('fontend')}}/js/revolution.extension.kenburn.min.js"></script>
    <script src="{{asset('fontend')}}/js/revolution.extension.layeranimation.min.js"></script>
    <script src="{{asset('fontend')}}/js/revolution.extension.migration.min.js"></script>
    <script src="{{asset('fontend')}}/js/revolution.extension.navigation.min.js"></script>
    <script src="{{asset('fontend')}}/js/revolution.extension.parallax.min.js"></script>
    <script src="{{asset('fontend')}}/js/revolution.extension.slideanims.min.js"></script>
    <script src="{{asset('fontend')}}/js/revolution.extension.video.min.js"></script>



<!-- thm custom script -->
<script src="{{asset('fontend')}}/js/custom.js"></script>

